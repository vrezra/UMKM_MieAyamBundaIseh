# Mie Ayam Dapur Bunda Iseh

## Nama UMKM
Mie Ayam Dapur Bunda Iseh

## Konsep Website
Website Mie Ayam Dapur Bunda Iseh dibuat sebagai platform digital untuk mempromosikan dan memudahkan pemesanan mie ayam khas dari UMKM Mie Ayam Dapur Bunda Iseh. Melalui website ini, pelanggan dapat melihat berbagai menu mie ayam, mengetahui informasi produk, serta melakukan pemesanan secara online dengan mudah dan cepat.

Desain website mengedepankan tampilan yang menarik dan user-friendly, sehingga pengunjung dapat dengan nyaman menjelajahi setiap fitur yang tersedia. Website ini juga dioptimalkan untuk berbagai perangkat, baik desktop maupun mobile, agar dapat diakses oleh lebih banyak pelanggan.

## Fitur Unggulan
- Daftar menu mie ayam lengkap dengan gambar dan deskripsi
- Fitur pemesanan online
- Informasi kontak dan lokasi UMKM
- Integrasi media sosial
- Tampilan responsif untuk berbagai perangkat

## Bahasa yang Digunakan
- HTML
- CSS
- JavaScript 